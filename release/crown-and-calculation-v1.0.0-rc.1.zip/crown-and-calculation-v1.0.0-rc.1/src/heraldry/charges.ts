/**
 * Original heraldic charges and shield shapes (crown-heraldry-1). All geometry is hand-built for this game:
 * charges on a 32×32 grid (drawn at 2.4 px stroke-equivalent after scaling), shields on a 64×72 grid.
 * Silhouettes are deliberately simple so they stay recognisable at 20 px.
 */
export const SHAPES = {
  heater: 'M6 6H58V30C58 52 44 64 32 70C20 64 6 52 6 30Z',
  kite: 'M32 3C47 6 58 16 57 32C56 50 44 62 32 70C20 62 8 50 7 32C6 16 17 6 32 3Z',
  roundel: 'M32 8A28 28 0 1 1 31.99 8Z',
  lozenge: 'M32 3L61 37L32 71L3 37Z',
  banner: 'M8 5H56V67L32 55L8 67Z',
  cartouche: 'M11 8Q32 0 53 8Q61 37 53 64Q32 72 11 64Q3 37 11 8Z',
  octagon: 'M20 5H44L60 21V51L44 67H20L4 51V21Z',
  tower: 'M6 14H13V7H21V14H28V7H36V14H43V7H51V14H58V40C58 58 44 66 32 70C20 66 6 58 6 40Z',
  pennant: 'M8 5H58L46 26L58 47H20L8 67Z',
  hexagon: 'M32 3L60 19V53L32 69L4 53V19Z',
} as const;
export type ShapeId = keyof typeof SHAPES;

/** Field divisions as polygons on the 64×72 grid (clipped to the shield). */
export const DIVISIONS = {
  plain: '',
  pale: 'M32 0H64V72H32Z',
  fess: 'M0 38H64V72H0Z',
  bend: 'M0 0H22L64 52V72H50L0 12Z',
  chevron: 'M0 56L32 30L64 56V72H48L32 50L16 72H0Z',
  quarterly: 'M32 0H64V36H32ZM0 36H32V72H0Z',
  chief: 'M0 0H64V22H0Z',
  saltire: 'M0 0H10L32 26L54 0H64V8L40 36L64 64V72H54L32 46L10 72H0V64L24 36L0 8Z',
  pily: 'M0 0H64L56 40L48 0L40 40L32 0L24 40L16 0L8 40Z',
} as const;
export type DivisionId = keyof typeof DIVISIONS;

/** Charges: filled silhouettes on a 32×32 box. */
export const CHARGES = {
  rook: 'M7 4H11V8H14V4H18V8H21V4H25V12L22 14V24L26 27V30H6V27L10 24V14L7 12Z',
  knight: 'M10 30V26C10 22 14 20 15 16C11 17 8 16 7 13L13 6L15 2L18 5C24 7 27 13 26 20L27 30Z',
  queen: 'M4 10L9 18L12 8L16 17L20 8L23 18L28 10L26 24H6ZM6 26H26V30H6Z',
  king: 'M14 2H18V6H22V10H18V13C24 14 27 18 26 24H6C5 18 8 14 14 13V10H10V6H14ZM6 26H26V30H6Z',
  pawn: 'M16 3A5 5 0 1 1 15.99 3ZM11 14H21L20 17C22 20 23 23 23 26H26V30H6V26H9C9 23 10 20 12 17Z',
  crown: 'M3 9L9 15L16 5L23 15L29 9L27 25H5ZM5 27H27V30H5Z',
  star: 'M16 2L19.6 11.6L30 12.2L22 18.8L24.6 29L16 23.4L7.4 29L10 18.8L2 12.2L12.4 11.6Z',
  tower: 'M5 30V9L9 5V2H12V5H14V2H18V5H20V2H23V5L27 9V30H19V21A3 3 0 0 0 13 21V30Z',
  sword: 'M15 1H17L18 4V20H23V23H18V27A3 3 0 1 1 14 27V23H9V20H14V4Z',
  key: 'M10 4A7 7 0 1 1 9.99 4ZM10 8A3 3 0 1 0 10.01 8ZM15 13L29 27L27 29L25 27L23 29L21 27L23 25L13 15Z',
  scales: 'M15 3H17V7H27V9L31 19C30 23 22 23 21 19L25 9H17V27H22V30H10V27H15V9H7L11 19C10 23 2 23 1 19L5 9V7H15Z',
  coin: 'M16 2A14 14 0 1 1 15.99 2ZM16 6A10 10 0 1 0 16.01 6ZM10 13L13 16L16 10L19 16L22 13L21 22H11Z',
  sun: 'M16 9A7 7 0 1 1 15.99 9ZM15 1H17V6H15ZM15 26H17V31H15ZM1 15H6V17H1ZM26 15H31V17H26ZM5 6L6.5 4.5L10 8L8.5 9.5ZM22 24L23.5 22.5L27 26L25.5 27.5ZM26 6L22 9.5L20.5 8L24.5 4.5ZM8.5 22.5L10 24L6.5 27.5L5 26Z',
  moon: 'M20 2A14 14 0 1 0 30 24A12 12 0 1 1 20 2Z',
  hourglass: 'M6 2H26V5H24C24 11 19 13 18 16C19 19 24 21 24 27H26V30H6V27H8C8 21 13 19 14 16C13 13 8 11 8 5H6Z',
  flame: 'M16 1C18 8 26 11 26 20A10 10 0 0 1 6 20C6 14 10 12 11 7C13 11 13 13 15 14C17 9 15 5 16 1Z',
  anchor: 'M16 2A4 4 0 1 1 15.99 2ZM15 10H17V12H22V15H17V27C21 26 24 23 25 19L22 19L27 14L30 21H28C27 26 22 30 16 30C10 30 5 26 4 21H2L5 14L10 19L7 19C8 23 11 26 15 27V15H10V12H15Z',
  quill: 'M28 2C22 4 14 9 10 18L8 24L5 29L7 30L11 25L16 23C23 19 27 11 28 2ZM12 20C14 15 18 10 23 7C20 11 17 15 12 20Z',
  chalice: 'M6 3H26C26 12 22 17 18 18V24H23V27H25V30H7V27H9V24H14V18C10 17 6 12 6 3Z',
  book: 'M3 6C8 4 12 5 15 7V28C12 26 8 25 3 27ZM29 6C24 4 20 5 17 7V28C20 26 24 25 29 27Z',
  laurel: 'M8 28C4 22 4 14 9 7L10 9C6 15 6 21 10 27ZM24 28C28 22 28 14 23 7L22 9C26 15 26 21 22 27ZM5 18L9 16L9 20ZM27 18L23 16L23 20ZM6 11L10 11L8 15ZM26 11L22 11L24 15ZM13 28H19V30H13Z',
  gate: 'M3 30V6H8V3H12V6H20V3H24V6H29V30H20V20A4 4 0 0 0 12 20V30Z',
  griffin: 'M6 30L10 20L6 16L12 14L14 6L18 2L20 6L26 6L22 10L26 14L20 16L22 22L28 26L20 26L18 30L14 24L12 30Z',
} as const;
export type ChargeId = keyof typeof CHARGES;

/** Crest ornaments above the shield (on a 64×16 band; drawn above y = 0). */
export const CRESTS = {
  crown: 'M14 14L18 4L25 10L32 1L39 10L46 4L50 14Z',
  coronet: 'M18 14L22 7L27 11L32 6L37 11L42 7L46 14Z',
  star: 'M32 1L34.6 7.6L41.6 8L36.2 12.4L38 19L32 15.2L26 19L27.8 12.4L22.4 8L29.4 7.6Z',
  helm: 'M22 15C22 7 26 3 32 3C38 3 42 7 42 15ZM26 9H38V11H26Z',
} as const;
export type CrestId = keyof typeof CRESTS;

/** Heraldic tinctures (fixed across themes like real arms; outlines use theme variables for contrast).
 *  v1.0: tuned to the royal palette — azure is royal blue, vert emerald, purpure amethyst, sanguine burgundy,
 *  or gold and argent silver — so crests, insignia and the interface read as one family. */
export const TINCTURES = {
  or: '#d8ae4c', argent: '#dde1e7', gules: '#b8323f', azure: '#2c55a0', vert: '#1f7a50', sable: '#23262e',
  purpure: '#6a4596', tenne: '#b8682c', sanguine: '#7a2234', celeste: '#7fa9d4', bronze: '#9a6b3c', steel: '#6c7686',
} as const;
export type Tincture = keyof typeof TINCTURES;

/**
 * v1.0 lines of partition: the edge between the two tinctures of a fess, chief or pale may be drawn straight, wavy,
 * embattled, indented or engrailed (as in real heraldry; the geometry is original). Other divisions stay straight.
 * Lines are rendering detail only: they are not part of an emblem's silhouette signature.
 */
export const LINES = ['straight', 'wavy', 'embattled', 'indented', 'engrailed'] as const;
export type LineId = typeof LINES[number];

/** An axis-aligned partition edge from (x0,y0) to (x1,y1) as path commands (the start point is already current). */
function edge(kind: LineId, x0: number, y0: number, x1: number, y1: number, side: 1 | -1): string {
  const len = Math.hypot(x1 - x0, y1 - y0);
  const n = Math.max(2, Math.round(len / 8));
  const dx = (x1 - x0) / n, dy = (y1 - y0) / n;
  // unit normal (pointing to `side`)
  const nx = (-dy / Math.hypot(dx, dy)) * side, ny = (dx / Math.hypot(dx, dy)) * side;
  const a = 2.6, f = (v: number) => Math.round(v * 100) / 100;
  let d = '';
  for (let i = 0; i < n; i++) {
    const px = x0 + dx * i, py = y0 + dy * i, qx = px + dx, qy = py + dy, mx = px + dx / 2, my = py + dy / 2;
    if (kind === 'indented') d += `L${f(mx + nx * a)} ${f(my + ny * a)}L${f(qx)} ${f(qy)}`;
    else if (kind === 'wavy') { const s = i % 2 ? 1 : -1; d += `Q${f(mx + nx * a * 2 * s)} ${f(my + ny * a * 2 * s)} ${f(qx)} ${f(qy)}`; }
    else if (kind === 'embattled') d += i % 2 ? `L${f(qx)} ${f(qy)}` : `L${f(px + nx * a)} ${f(py + ny * a)}L${f(qx + nx * a)} ${f(qy + ny * a)}L${f(qx)} ${f(qy)}`;
    else if (kind === 'engrailed') d += `A${f(len / n / 1.6)} ${f(len / n / 1.6)} 0 0 ${side === 1 ? 1 : 0} ${f(qx)} ${f(qy)}`;
    else d += `L${f(qx)} ${f(qy)}`;
  }
  return d;
}
/** The second-tincture region of a division, with its line of partition (straight lines reuse DIVISIONS). */
export function divisionPath(division: DivisionId, line: LineId = 'straight'): string {
  if (line === 'straight') return DIVISIONS[division];
  if (division === 'fess') return `M0 72L0 38${edge(line, 0, 38, 64, 38, -1)}L64 72Z`;
  if (division === 'chief') return `M0 0H64V22${edge(line, 64, 22, 0, 22, -1)}Z`;
  if (division === 'pale') return `M32 0H64V72H32${edge(line, 32, 72, 32, 0, -1)}Z`;
  return DIVISIONS[division];
}

/**
 * v1.0 event motifs drawn behind (or around) a tournament crest at medium and large sizes, so every event kind has
 * its own emblem language: the league's compony bordure, the Swiss Open's compass rose, the Challenger's crossed
 * swords, the Club Weekend's pennants, the Crown Championship's sunburst, the Zonal Championship's battlement and the
 * Regional Cup's ribbon. Federation titles use the `order` star instead (src/ui/Emblem.tsx).
 */
export const MOTIFS = ['compony', 'compass', 'swords', 'pennants', 'rays', 'battlement', 'ribbon'] as const;
export type MotifId = typeof MOTIFS[number];
