# Implementation decision log

Research decisions D01–D12 (docs/research/18_DECISION_LOG_AND_OPEN_RISKS.md) remain binding. The
entries below record implementation decisions and conflicts resolved during M0/M1.

| ID | Decision | Reason / evidence |
| --- | --- | --- |
| I01 | **Production engine = custom TypeScript engine** (`crown-search-1` + `crown-eval-2`) in a Web Worker. Fairy-Stockfish is used only as a development oracle and benchmark reference, not shipped. | The npm WASM build `fairy-stockfish-nnue.wasm@1.1.12` (GPL-3.0) is compiled with pthreads and requires `SharedArrayBuffer`, i.e. cross-origin isolation (COOP/COEP). That is not available from the PowerShell fallback server or `file://`, is fragile for an iPhone home-screen PWA, has no single-thread fallback, and bundling it would make the distributed app a GPL combined work — a licensing choice that belongs to the project owner. Research D04 explicitly allows the documented custom fallback. |
| I02 | Rules verified against two independent references: pyffish 0.0.90 (5,000 positions, 47,884 successor states) and a native Fairy-Stockfish build from commit `3a95e072f8e60b94ad4d04a3c6d98129c772a301` (perft 1–5). | Research doc 04 gate "reproduce against the production implementation". |
| I03 | Search features kept only where self-play ablation showed benefit or no harm (docs/ENGINE_BENCHMARKS.md). Null-move and aspiration windows were neutral within error; kept because they did not hurt and reduce node counts at depth. | Research doc 05: "Use evidence to choose optimizations." |
| I04 | Difficulty = node budgets + bounded near-best sampling for L1–L4. Ratings of levels come from measured engine-vs-engine matches anchored at L1 = 800 (`src/engine/calibration.json`). | Hardware-independent strength; research forbids difficulty labels as ratings. The anchor value is arbitrary (no human data). |
| I05 | AI opponents are fixed anchors: their rating/RD snapshot (from calibration) is used in the player's Glicko-2 update and they never change. | Research doc 06: anchor agents with fixed versions do not drift. |
| I06 | One rated game = one Glicko-2 rating period; pools per time control (blitz, rapid, classical). Untimed games are never rated. Any assistance event makes a game unrated (no in-game assistance exists in M1). | Research doc 06 policy. |
| I07 | Rated clocks pause when the app is hidden and when a saved game is reopened; pauses are recorded with the game. Time between closing and reopening is not charged. | Research doc 04: pause on suspension to avoid iOS background penalties. |
| I08 | Engine draw behaviour: the engine accepts a draw offer / claims an available draw only if its own last evaluation is ≤ −60 cp (or level and ≥ 60 plies). This is a player decision, never an adjudication. | Crown rules: no engine evaluation decides a result. |
| I09 | Analysis policy `std-d7`: exact full-window scores at depth 7 and 6 for {top screened moves, engine best, played move}; screening of all legal moves at depth 3. Grading/accuracy = research v0 (s = 200 cp, k = 4, fixed bins) labelled **experimental**. Additional rule: an immediately winning capture (SEE > 0) is never "Great". | Research doc 07 (root-constrained comparable policy; uncalibrated thresholds must be disclosed). The SEE rule was added after a real report labelled recapturing a hanging knight as Great. |
| I10 | Brilliant requires: Great conditions + ≥ 200 cp material investment along the engine line + not a recapture + a deeper (depth + 2) verification where the move keeps expected score ≥ 0.5 and ≥ 0.10 above the alternative. It is heuristic, never claimed as proof. | Research doc 07. |
| I11 | Storage: hand-written IndexedDB wrapper (no Dexie) to avoid an unaudited dependency; `fake-indexeddb` only in tests. Single-writer lease via Web Locks; second tabs are read-only. | Research doc 12. |
| I12 | Training retries store `setupMoves` (the original history) so repetition state is exact, are untimed and unrated, and never modify the source game. | Research doc 07 "replay the mistake from the original pre-move state". |
| I13 | Lab (M2 foundation) shows only descriptive rates with ≥ 10 opportunities across ≥ 3 games and game-clustered bootstrap intervals; dimensions without an M1 rubric say "not measured". | Research doc 06 evidence rules; no fabricated scores. |
| I14 | Repository license left `UNLICENSED` in package.json. | Choosing an open-source license is the owner's decision. |
| I15 | Sandbox Exchange (own-game speculation with fictional sandbox balances, excluded from official wealth/records/achievements) is adopted into the M4 design. | Directive §11; resolves the research "no trading on own games" rule by separating a sandbox ledger from the official exchange. |
| I16 | **v0.3.0 federation results use three tiers**: your games (full, rated), up to three featured engine games per round (full, replayable), and ≈ 1,020 summary results per round from a Davidson model (ν = 0.9 fitted on 1,779 engine games) on hidden strengths. Summary results are labelled as such and never shown as games. | Directive §4; playing every pairing on the engine would take hours per round in a browser. |
| I17 | Competitors have a hidden engine-scale strength that drives results and their engine profile; forecasts, NPC traders and research use only the public Glicko-2 rating. | Prevents information leakage from simulation internals into markets; ratings converge on strength (r ≈ 0.99 after one season). |
| I18 | Featured-game markets are closed and the closure committed **before** the game is generated. | The result must not exist while trading is possible (directive §9). |
| I19 | One authoritative service (`FederationService`) with clone → compute → validate → single-transaction commit guarded by the (season, round) cursor; journal ids are idempotency keys. | Duplicate finalization/prize/settlement, crash and multi-tab safety (directive §17). |
| I20 | Economy: fixed per-season issuance (prize pools + sponsors), capped treasury replenishment (≤ 8,000 ₵ toward 25,000 ₵), competitor season expenses (75 % of balance) to a sink, NPC wallets capped. | The first simulation showed competitor balances growing without bound (no sink) and the treasury draining; both fixed and re-measured (docs/V3_ECONOMY.md). |
| I21 | NPC order: noisy/biased traders first, the informed analyst last. | With the analyst first, prices stayed ~18 points from the public model and a trivial "buy the biggest model edge" strategy out-earned chess; now opening prices sit within a few points of the model. |
| I22 | Styles must be measured before they are shown. The v0.3.0 move-filter policy (crown-styles-2) failed; the M3 pass replaced it with **opening-repertoire styles** (crown-styles-3: book moves within 30 cp at depth 7, style-weighted, seeded). Tactical and Positional passed behaviour and strength parity; Aggressive, Defensive and Endgame failed and play Universal. | Directive §4 allows opening preferences; docs/V3_STYLES.md. |
| I23 | Sandbox Exchange deferred to v0.4.0 (blocker: a design in which the player cannot profit by losing their own casual game). Ledger isolation for `sandbox:` accounts is implemented and tested. | Directive §11 allows documenting it with blocker and next action. |
| I24 | No debt anywhere: unpaid upkeep suspends an asset; low cash unlocks a non-cash recovery voucher (Challenger entry) once per season. | Research doc 10; bankruptcy recovery without negative balances. |
| I25 | Training Hall gives only unrated sparring against the next opponent's exact profile. | Directive §9: functional purchases must not buy rating points or rated-game advantages; practice is legitimate preparation. |
| I26 | Spectator shows each side's actual engine thinking time instead of a game clock. | Featured games are node-limited (deterministic, crash-replayable); a running game clock would be decorative. |
| I27 | No tournament-winner markets and no in-match trading in M3. | Directive §6/§7 make both conditional on correct settlement and legitimate timing; designs are in docs/M4_PLAN.md. |
| I28 | One generalized LMSR (n states, subset claims, payout vectors) for every market family; no separate pricing engines. | Research doc 09: one ledger per event cluster, coherent claim prices, a single solvency proof. |
| I29 | Market families are listed on four distinct regions (never the player's), and overlapping event clusters are never open at the same time (champion market closes before the final-four market opens). | Doc 09 forbids duplicated deterministic payoffs across concurrently listed contracts. |
| I30 | Joint champions settle by a ½/½ payout vector on the 8-state final-four model instead of a 12-state model. | Keeps the researched 8-state reference; a split vector lies in the simplex, so the funded bound still holds (tested). |
| I31 | In-play trading only when the player watches a featured match live; each move is computed after the previous trading window and committed with its NPC reactions. Background matches close at the first move. | Doc 09 live-move sequence; no precomputed outcome while trading. |
| I32 | Censored featured games (400-ply limit) cancel their market on the published vector instead of settling a draw. | Reconciliation finding; a censored game is not a result. |
| I33 | Sandbox markets open at a funded rating prior and cancel at that same prior; the player may only back themselves. | Removes the forced-void and deliberate-loss exploits (doc 09 initial-prior bound b·ln(1/min p0)). |
| I34 | Sponsorship stipends are priced at ≥ 30% of the competitor's average season prize earnings (and ≥ 10% of their division pool), repriced at renewal; share 25%. | First sim showed contracts on top players were a passive-profit machine; now profit requires outperforming history. |
| I35 | Club upgrades escrow half their cost (refundable, counted in book value) and spend half. | Upgrades must be real choices with costs; book value never counts spent money. |
| I36 | Theme system: Obsidian & Crimson default, Midnight & Gold, Ivory & Slate; independent board palettes; preferences in localStorage (per-device convenience, not game state). | Directive Part VI; preferences are not career data and need no migration. |
| I37 | Play uses crown-search-2 + crown-eval-4; analysis, puzzle verification and the assistant keep the pinned crown-search-1 + crown-eval-3. | The new engine is far stronger (+374 [255, 545] at equal time), but the analysis outcome map, grade corpus and puzzle verification were measured on the M3 engine; switching them requires a refit, not a silent change. Game records label the engine that actually played. |
| I38 | Fairy-Stockfish WASM evaluated and not integrated. | GPL-3.0 vs an UNLICENSED repository (owner's decision), SharedArrayBuffer/COOP-COEP unavailable from file:// and the PowerShell server, no single-thread build, 128 MiB initial memory. |
| I39 | Full-game evaluation-weight styles not shipped. | Pilot: 17–29% move changes but signature shifts −8…+4 pp, below the pre-registered +10 pp; machinery left disabled. |

## Conflicts noted

- Directive asks to "investigate Fairy-Stockfish… If infeasible use the fallback": feasibility was investigated (I01). Integration as an optional, separately licensed engine module behind cross-origin isolation remains possible later (see ROADMAP).
- Research recommends Tauri for a Windows wrapper; the directive asks for a BAT/PowerShell launcher. M1 ships the launcher (no native wrapper).

## M5 addendum (Living Rivalry & Heraldry)

| # | Decision | Reason |
| --- | --- | --- |
| H01 | The addendum is implemented on top of v0.4.0; the main v0.5.0 prompt was not received. | Nothing to integrate with beyond the existing game; no requirement invented. |
| H02 | Emblems are data (`EmblemSpec`) rendered by one SVG component; tinctures fixed, outlines from theme variables. | One reusable system, theme-safe, testable (self-contained SVG, distinct signatures, monotonic prestige). |
| H03 | Federation titles are fictional (Squire/Knight/Paladin/Sovereign) and norm-based with an Elo-inverse performance capped at ±800. | Mirrors the structure of real title systems without claiming FIDE meaning; a linear performance formula capped too low to reach the higher norms. |
| H04 | Norms use opponents' ratings at the end of the event, not at pairing time. | Per-game rating snapshots are not stored for summary results; documented approximation. |
| H05 | Rivalries are derived on demand from recorded games, never stored or fed back. | Guarantees they cannot change results, pairings or strength, and survive saves without migration. |
| H06 | Only the first two meetings of a pair per season score; upsets once per season; ×0.7 decay. | Anti-farming and bounded intensity. |
| H07 | AI club finances are real ledger journals (5% dues, 60% operations to the sink). | Club treasuries must be legitimate records, and the ledger must stay conserved. |
| H08 | Ceremonies have deterministic ids and are created only in the round commit. | No duplicate awards; every ceremony traces to a recorded result. |

## v0.5.0 "Sovereign Intelligence"

| # | Decision | Reason |
| --- | --- | --- |
| S01 | The play engine (crown-search-2 + crown-eval-4) becomes the single foundation for every intelligence system. | Directive Phase 3; v0.4 analysed games with a weaker, differently scaled engine than the one that played them. |
| S02 | Refit the expected-score map (v2) instead of reusing v1. | Held-out: v1 on the new scale is no better than the placeholder; v2 is better on Brier, log loss and ECE. |
| S03 | Historical reports are never relabelled; `legacy-v1` mode exists only to reproduce them in tests. | Preserve history without mixing methodologies. |
| S04 | Puzzles that fail canonical verification are retired, not deleted; lines shortened only to a verified prefix. | Attempts must keep pointing at real puzzles; nothing unverified is served. |
| S05 | Sovereign Max = more time + larger table on the same engine; no new search features. | Only budget scaling was validated in this release; per-node improvements need their own paired evidence. |
| S06 | L9 calibration is derived from one L9–L8 match at time-scaled budgets. | Full-length time-limited calibration would take many hours; the derivation and its inherited uncertainty are documented. |
| S07 | Only the 10 s Max budget is rated; other budgets are casual. | A rating must correspond to a measured configuration. |
| S08 | Fairy-Stockfish stays a development reference. | Unchanged constraints (GPL-3.0, threads/isolation, memory); owner decision required. |
| S09 | Engine-build changes for federation events are recorded and announced, not hidden; no result is regenerated. | Directive: no silent engine changes during financially consequential events. |
| S10 | The launcher reuses a running game rather than moving to another port; a forced port change prints a warning. | Different ports are different storage origins (empty career). |
| S11 | Cosmetics are a sink with no resale and no gameplay effect; earned cosmetics cannot be bought. | Meaningful money use without pay-to-win or purchasable honours. |
| S12 | No improvement badge was added. | The registered protocol named by the directive was not provided; the Lab keeps its "insufficient evidence" rule. |
