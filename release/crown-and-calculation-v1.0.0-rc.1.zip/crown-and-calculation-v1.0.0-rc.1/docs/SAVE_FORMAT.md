# Save, export and import formats

All data lives in the browser's IndexedDB database `crown-calculation` (schema `crown-save-1`,
IndexedDB version **4** since v0.4.0) on the device. Nothing is sent anywhere.

## Object stores

| Store | Key | Contents |
| --- | --- | --- |
| `games` | `id` | `GameRecord` (src/games/types.ts): variant/rules/adjudication/notation versions, initial FEN, optional setup moves, every move with CCN, SAN, pre/post Zobrist hash, FEN after the move, clocks before/after and elapsed time, engine search metadata for engine moves, assistance and pause events, result, termination, opponent snapshot (engine profile, calibration id), rating event id, report ids, checksum. |
| `ratingEvents` | `id` = `rating:<gameId>:<pool>` | Immutable Glicko-2 events with inputs, expected score, before/after r/RD/σ, rank before/after, explanation terms. |
| `ratingState` | `pool` | Current pool state (derivable by replaying `ratingEvents`). |
| `reports` | `id` = `report:<gameId>:<checksum12>:<engineBuild>:<settings>:<gradingId>` | Immutable analysis reports. A new engine, setting or methodology produces a new id; old reports are never overwritten. |
| `analysisJobs` | `job:<gameId>:<settingsId>` | Job intent and status (queued/running/complete/partial/cancelled/failed). |
| `meta` | `key` | Schema marker, last backup time. |
| `attempts`, `trainingRuns`, `bookmarks` | `id` | v0.2.0 Academy attempts, training runs, position bookmarks. v0.10 adds two optional bookmark kinds (additive, no migration): `kind: 'favourite'` (`id` = `fav:<gameId or wg:fixture>`, `ply` = −1) for Replay Library favourites, and `kind: 'position'` (`id` = `pos:<gameId>:<ply>:<line>`, with `fen`, `line` and `sans`) for sandbox positions saved from a replay. Records without `kind` are the original ply bookmarks. Bookmarks are included in backups. |
| `world` | `key` = `world` | Federation cursor: seed, season, round, player membership, titles, history (v0.3.0). |
| `seasons` | `id` = `season:<n>` | Season plans: 128 league circuits, Swiss events, championship and Club Weekend brackets. |
| `competitors` | `id` | 2,048+ competitor records (identity, hidden strength, public Glicko-2, career, titles). |
| `rounds` | `id` = `<season>:<round>` | Fixtures (player, featured, knockout) with results + compact summary results. |
| `worldGames` | `id` = `wg:<fixture>` | Full move records of featured AI-vs-AI games. |
| `journal` | `id` | Immutable double-entry journals (integer microcrowns). |
| `accounts` | `account` | Account balances (must equal the journal replay). |
| `markets`, `positions` | `id` | Exchange markets (LMSR state, history, status) and holdings. |
| `assets` | `id` | Owned assets (acquired season, upkeep, suspension). |
| `finance` | `key` | Net-worth history and player extras (watchlist, sponsors paid, vouchers, paper forecasts with price/model snapshots, sandbox refill marker). |
| `liveGames` | `id` = fixture id | v0.4.0: in-play featured game — moves so far, seed, status, published price/model points. |
| `contracts` | `id` | v0.4.0: sponsorship contracts (stipend, share, paid, earned, status). |

Markets gained optional fields in v0.4.0 (`kind`, `outcomes`, `claims`, `model`, `payout`, `rules`, `live`, `q0`, `cancelVector`, `ref`); v0.3.0 match markets without them are read as W/D/B categorical markets, so no record is rewritten. Display preferences (theme, board) live in localStorage, not IndexedDB.

**v0.10 compact persistence (crown-persist-1, `src/federation/persist.ts`; no IndexedDB version change).**
`competitors` holds chunk records `{ id: "~c:<nnnn>", kind: "competitors", v: 1, records: Competitor[] }` (up to 512
competitors each, by competitor index); `accounts` holds `{ account: "~a:<nnnn>", kind: "accounts", v: 1, accounts,
balances }` for the competitors' `comp:<id>` accounts (all other accounts stay individual records); a `rounds`
record stores its tier-3 results as `packed: { v: 1, n, events, ev, w, b, r }` with `abstract: []` (events joined by
newlines, event indices and ids by commas, one result character each: `1`, `0`, `=` for a draw, `.` for none). The
app expands these on load. Records of older saves are read as they are, and each individual competitor or
competitor-account record is deleted in the transaction that first writes its chunk. Backups contain the stored
records unchanged; the import's ledger check reads account chunks. A pre-v0.10 build cannot read a v0.10 federation.
The world records its size in `world.topology` (crown-topology-1 2,048 when absent, -2 4,096, -3 10,240).

Every federation/economy command writes all changed records in **one** transaction guarded by the
committed (season, round) cursor (docs/V3_FEDERATION.md §4).

Finalization writes the finished game, its rating event, the pool state and the analysis intent in
**one** IndexedDB transaction; the event key makes retries idempotent (tested in tests/storage.test.ts).
Finalized games are immutable (only bookmarks may change).

## Notation (ccn-1)

`<from><to>[promotion]`, squares `a1`–`f6`, files a–f left to right from White, ranks 1–6 from
White's side. Promotion letters `q`, `r`, `n` (mandatory on the last rank). Identical to the
Fairy-Stockfish UCI spelling for variant `losalamos`. Display SAN (`csan-1`) is derived, never stored
as the source of truth. This is **not** standard-chess PGN.

## Backup bundle (crown-backup-1)

```json
{ "format": "crown-backup-1", "appSchema": "crown-save-1", "variantId": "crown-la6-v1",
  "exportedAt": "...", "appVersion": "0.3.0",
  "counts": { "games": 0, "ratingEvents": 0, "reports": 0 },
  "payloadSha256": "<sha-256 of JSON.stringify(payload)>",
  "payload": { "games": [], "ratingEvents": [], "ratingState": [], "reports": [],
               "attempts": [], "trainingRuns": [], "bookmarks": [], "federation": { "world": [], "journal": [], "...": [] } } }
```

Import validates everything before writing: format/variant/schema, payload checksum, every game
replayed legally with the production rules and every stored `fenAfter` matched, finalized-game
checksums, and that each rating pool equals a replay of its event ledger. Into an empty career the
bundle is restored completely; into an existing career only new games/reports are merged and the
active rating ledger is never rewritten.

## Single game (crown-game-1)

`Export game` writes `{ format: "crown-game-1", notation, canonical, record }` where `canonical`
is the checksummed rules content (`id, variantId, rulesVersion, initialFen, setupMoves, moves, result, termination`).

## Migrations

`src/storage/db.ts` holds an ordered `MIGRATIONS` list applied in `onupgradeneeded`:

| Version | Release | Change |
| --- | --- | --- |
| 1 | v0.1.0 | Initial schema |
| 2 | v0.2.0 | Adds `attempts`, `trainingRuns`, `bookmarks` (additive) |
| 3 | v0.3.0 | Adds the 11 federation/economy stores (additive) |
| 4 | v0.4.0 | Adds `liveGames` (in-play featured games, persisted after every move) and `contracts` (sponsorship contracts) (additive) |

Both upgrades are **additive**: no existing record is read, rewritten or deleted, so a v0.2.0 career opens
unchanged in v0.3.0 (verified: `tests/storage.test.ts` v1→v2, v2→v3 and v3→v4, and in Chromium by
`e2e/federation.mjs`, which plays a rated game in the real v0.2.0 build, then serves the v0.3.0 build on
the same origin and checks the games, rating events and rating are identical). The federation is empty
until the player founds it. Future data-transforming migrations must follow research doc 12: export a
recovery backup first, check quota, validate the new store before switching, keep the old data until
confirmed.

### Backups in v0.3.0

The `crown-backup-1` payload gains an optional `federation` object holding every federation store.
It is restored **only into an empty career** (the federation is one consistent world, never merged), and
only after validation: every journal must balance, and every account balance must equal the replay of
the journals (a tampered balance is rejected — tested). Older backups without `federation` still import.

### v0.5.0 (no schema change, IndexedDB v4)

v0.5.0 adds **no object store and no version bump**. New data is carried in optional fields of existing records,
written lazily, and older builds ignore it:

| Where | Field | Meaning |
|---|---|---|
| federation `world` | `engineCommitments[]` | `{season, round, build, at, liveGamesInProgress}` — engine build in force from that round (appended on the first load of a build) |
| federation `world` | `featured[]` (M5 addendum) | the 28 featured rivals |
| federation `extra` | `cosmetics` | `{owned[], equipped{frame,banner,board,avatar}, avatarSeed}`; purchases are journals `cosmetic:<id>` (player cash → sink) |
| federation `extra` | `ceremonies[]`, `favorites[]` (M5 addendum) | ceremonies to present; followed careers |
| game `white/black.engine` | `config` | exact engine configuration used (rules, backend, build, table size, time cap, node cap, selection) |
| game `moves[].engine` | `score`, `stopReason`, `build` | provenance of each engine move |
| analysis job | id `job:<game>:<preset>:<build>:<grading>` | jobs keyed by engine and grading version (old `job:<game>:<preset>` jobs stay as they are) |
| analysis report | unchanged schema | new reports: build `crown-search-2+crown-eval-4`, grading `crown-grade-v2-experimental`, accuracy `crown-accuracy-v2`; old reports untouched |
| bundled puzzle data | `canonical`, `retired`, `revisedFrom` | v0.5 re-verification; attempts on retired puzzles keep pointing at a real puzzle |

Verified in Chromium by `e2e/v5-journey.mjs`: the real v0.4.0 build (commit `d4dbbe6`) creates a career (federation,
club, trade, rated game with its v0.4 analysis report, Academy attempt); the v0.5.0 build on the same origin finds
every game, rating event, rating state, report, attempt, journal and balance byte-identical, keeps the historical
report, and can re-analyse the game with the current engine as a second report. Backups (`crown-backup-1`) are
unchanged; the same journey exports a backup and restores it into an empty profile with identical data.

Rollback: because nothing is rewritten, the v0.4.0 build still opens a career touched by v0.5.0 (it ignores the
extra fields). Export a backup before upgrading regardless.

## Durability limits

Browser storage is best-effort unless the browser grants persistence (the Library shows the status).
Safari/iOS may evict site data. Export backups regularly; only an external file survives eviction.

## v0.9: progress records in backups
The `crown-backup-1` payload gains an optional `progress` array of `{ key, value }` meta-store records with the prefixes
`ach:` / `achtoast:` / `vault:` (Sovereign Vault unlocks, shown notices, backfill flags — `vault:backfilled` and, from
v0.11, `vault:backfilled:crown-vault-2` for the expansion's one-time back-fill) and `grim:` (Grimoire lesson
attempts, chapter completion, plan settings). It is covered by `payloadSha256` like the rest of the payload; older backups
without it import unchanged. Restore into an empty career writes all of them; merging into an existing career writes only
`grim:` learning progress (achievements stay with the career that earned them). Every write is put-if-absent: existing
records are never overwritten. Tests: `tests/storage.test.ts`.

## v0.10: population model (no schema change)
Federations founded from v0.10 store `populationModel: "crown-population-2"` in the `world` record (the full 0–4,000+
strength spectrum, docs/RATING_SPECTRUM.md). A world without the field is `crown-population-1` and is never rescaled:
no competitor record is rewritten; only its future turnover entrants into divisions 7–8 come from the beginner
distribution. Game records against the new beginner opponents carry the exact engine profile (`engine.profile`, with an
`error` model), calibration id `cal-2026-11-04-beginners-crown-error-1`, and per-move `selected` values
`error-random` / `error-sample`; older builds ignore them. Tests: `tests/ratingSpectrum.test.ts`.

## v0.10: Played Like records and report field (no schema change, IndexedDB v4)
Two additive, optional fields (docs/PLAYED_LIKE.md):

| Where | Field | Meaning |
|---|---|---|
| analysis report | `playedLike` | `{ modelId, white, black }` — the Played Like Performance Elo of both sides, computed when the report completed (`src/analysis/playedLike.ts`). Absent on older reports; the app computes the same value from the report's stored plies. Reports stay immutable. |
| finalized game | `playedLike[]` | permanent records of the player's own estimate, one per model id (`crown-pl-record-1`, `src/analysis/playedLikeRecords.ts`): `gameId`, `at` (game end), `recordedAt`, `pov`, `opponent {id, name}`, `result` (1 / ½ / 0 for the player), `pool`, `career {before, after, rd}` from the game's rating event (null if unrated), `estimate` (value, 80 % / 95 % range, scale, informative moves, or the reason there is no number), `confidence` (`adequate` / `low` / `insufficient` / `unavailable`), `modelId`, `reportId`. |

* The game checksum covers only rules-relevant content (`canonicalGame`), so adding records never changes it; moves,
  result and rating events are never touched (`CrownDB.setPlayedLikeRecord` writes only this field).
* Records are carried by `crown-backup-1` because games are; older backups import unchanged (no records) and get them
  through the backfill below.
* **Migration from v0.9 and earlier:** on boot (`AppServices.backfillPlayedLike`, off the boot path) every finalized game
  that has a complete Standard analysis but no record for the current model gets one; games without analysis get theirs
  when their analysis completes (the analysis queue writes it). A model update adds a record under the new model id and
  keeps the old one; statistics never mix model ids.
* Tests: `tests/playedLikeRecords.test.ts` (record contents, reload, backup round trip, v0.9 backfill, version separation,
  low-confidence exclusion).

## v0.11: Circuit Grades (no schema change, IndexedDB v4)
* `Competitor.rank?: [step, protect, highestStep, highestSeason, lastScore×10]` in the existing competitor chunks;
  `WorldState.player.rank?` (`PlayerRank`: step, protection, highest `{step, season, round, via}`, last checkpoint,
  log of step changes ≤ 200, origin); `Ceremony.kind` may be `'rank'`. All optional and additive.
* Saves without them get them at load, deterministically, from their stored season records and the current season's
  rounds (`migrateRanks`, docs/FEUDAL_RANKS.md §7); nothing else in a record changes. Written with the next commit
  that touches the record. Backups carry the fields unchanged.
* Tests: `tests/ranks.test.ts` (reload through a checkpoint and a season end, backup round trip, a save with every
  rank field removed).

## v0.11: trophies and legacy header (no schema change)
Package I adds meta-store records only (additive, IndexedDB version unchanged): `trophy:<key>` (one per trophy, written
put-if-absent; `{ key, defId, kind, tier, name, season, event, evidence, earnedAt, replay?, at, backfill, registry:
"crown-trophies-1" }`), `trophyseen:<key>` (ceremony shown), `legacy:backfilled` (one-time back-fill marker) and
`legacy:prefs` (`crown-legacy-prefs-1`: `{ v: 1, name, banner, featured[], insignia, accent, showcase[], honour }`).
All four prefixes are carried in the backup `progress` array; restore into an empty career writes them put-if-absent,
merging into another career does not import them (they belong to the career that earned them). Older builds ignore
them. Tests: `tests/legacy.test.ts`. See docs/LEGACY.md.

## v0.11: Exhibition Arena archive (no schema change, IndexedDB v4)
Unofficial exhibitions (any two Federation competitors, `src/app/exhibition.ts`, crown-exhibition-1) are kept in the
`meta` store under their own prefixes, apart from every official record:

| Key | Value |
|---|---|
| `exh:<timestamp>-<seed36>` | `ExhibitionGame` — `kind: "exhibition"`, `official: false`, `schema`, `createdAt`, `finishedAt`, `status` (`playing` / `finished`), `seed`, `nodeCap` (30,000, as featured games), `initialFen`, `white` / `black` sides (competitor id, name, career Elo and RD at the start, division, region, title, own and played style, persona id, the engine profile used), `moves` (CCN, SAN, FEN after, the moving engine's published score, depth, nodes, ms), `result`, `termination`, `checksum` (SHA-256 of id, moves and result once finished). Saved after every move, so an unfinished exhibition resumes on the same timeline. |
| `exhrep:<exhibition id>` | The exhibition's Match Analysis report (standard settings and queue; job ids `job:exh:…` in `analysisJobs`), with its `playedLike` field. **Never** in the `reports` store, so no career statistic, Vault fact, Lab/Academy item or permanent Played Like record can read it. |

* Exhibitions never write `games`, `reports`, `ratingEvents`, `ratingState` or any Federation store; bookmarks
  (favourites, saved sandbox positions) on an exhibition use its `exh:` id and are ignored by the Vault.
* Backups: `crown-backup-1` gains the optional `payload.exhibitions` (`{ key, value }[]` with both prefixes), validated
  on import (prefixes, legal replay of every move, stored FENs, finished games terminal) and imported put-if-absent in
  both restore and merge mode. Older backups have none; older builds reject a backup that carries the field.
* Deleting an exhibition removes its two records, its analysis jobs and its bookmarks.
* Tests: `tests/exhibition.test.ts` (archive reload, backup round trip and tamper rejection, deletion, isolation).

## v0.11: career rating origin (crown-career-1, no schema change)
The `meta` store gains a record `career` = `{ model: "crown-career-1", id, ratingStart, origin: "new" | "legacy",
createdAt, previousArchiveId? }` (docs/CAREER_RATING.md). A database created by v0.11+ starts its pools at 0; a
database from an older build is marked `legacy` (start 1500) on first open if it holds any game, rating event, rating
state or Federation, and is otherwise treated as a new career. No existing record is rewritten. The backup payload
gains an optional `career` (covered by `payloadSha256`); a backup without it replays from 1500, and a restore into an
empty career adopts the backup's origin. Start New Career clears every store of `crown-calculation` in one transaction
after a full backup was exported; a copy of that backup is kept in a separate database `crown-calculation-archive`
(store `backups`, key `archive:<exportedAt>`, the exact file text) when storage allows. Older builds ignore the record.

## v1.0: first-run guide (no schema change)
Package V adds one meta-store record, `tour:state` (`crown-tour-1`, `src/app/onboarding.ts`):
`{ v: 1, dismissed, ack: { <step>: iso }, seen: { analysis?: iso }, restarts }`. It is learning progress, not a career
record: the `tour:` prefix is carried in the backup `progress` array, restored put-if-absent into an empty career and
merged put-if-absent into another career. Unknown or malformed values are sanitised on read (an absent record is a
fresh guide). Older builds ignore it. Tests: `tests/onboarding.test.ts`.
